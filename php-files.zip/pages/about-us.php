<?php
$pageTitle = 'About Us';
include __DIR__ . '/../partials/header.php';
?>

<div class="grid-container">
    <div class="grid-x grid-padding-x">
        <div class="cell">
            <h1>About Our School</h1>
            <p>Welcome to Park Community School. This is a test page for Foundation 6.</p>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../partials/footer.php'; ?>